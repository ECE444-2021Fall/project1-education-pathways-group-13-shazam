import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='yanchen',
    application_name='pathfinder',
    app_uid='JBchJB7HKS4rV4Tqd8',
    org_uid='RDg5ZCghtMMC6TZW9d',
    deployment_uid='fcff9b3b-762b-4884-9ae0-4c68036c196a',
    service_name='pathways-backend',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.5.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'pathways-backend-dev-app', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
